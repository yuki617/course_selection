import React, { Component } from 'react';
import { Redirect} from 'react-router'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import TextField from 'material-ui/TextField';
import App from './App'

class Login extends Component {
constructor(props){
  super(props);
  this.state={
    username:'',
    password:'',
    fireRedirect: false
  }
 }

 submitForm = (e) => {
  e.preventDefault()
//   this.props.form.validateFields((err, values) => {
//     if (!err) {
      fetch(
        `http://127.0.0.1:5000/login?username=${this.state.username}&password=${this.state.password}`
      )
        .then(res => res.json());
    // }
//   });
  this.setState({ fireRedirect: true })
}

handleClick(event){
    if(1){
    console.log("Login successfull");
    }
    // else if(response.data.code == 204){
    else if(0){
    console.log("Username password do not match");
    alert("username password do not match")
    }
    else{
    console.log("Username does not exists");
    alert("Username does not exist");
    }
    // })
    // .catch(function (error) {
    // console.log(error);
    // });
    }
sendData(e){
        console.log(e)
        let username = e.arget.value;
        this.props.Callback(username);      
    }


render() {
    const { from } = '/'
    const { fireRedirect } = this.state.fireRedirect
    console.log(this.state.username)
    return (
      <div>
        <MuiThemeProvider>
          <div>
          <AppBar
             title="Login"
           />
           <TextField
             hintText="Enter your Username"
             floatingLabelText="Username"
             onChange = {(event,newValue) => this.setState({username:newValue})}
            />
           <br/>
             <TextField
               type="password"
               hintText="Enter your Password"
               floatingLabelText="Password"
               onChange = {(event,newValue) => this.setState({password:newValue})}
               />
             <br/>
             <div>
        <form onSubmit={this.submitForm}>
        <button type="primary"
            onChange={(e) => this.sendData(e)} 
            htmlType="submit"
            className="login-form-button" style={style}>Submit</button>
        </form>
        {this.state.fireRedirect && (
            <Redirect  to={{pathname:'/table',state : {
                username : this.state.username}}
            }/>
          )}
        </div>
         </div>
         </MuiThemeProvider>
      </div>
    );
  }
}
const style = {
 margin: 15,
};
export default Login;